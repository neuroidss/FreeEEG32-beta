sudo openocd -f STM32H743ZI_alpha1.5.cfg

