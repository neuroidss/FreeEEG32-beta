sudo openocd -f STM32H743ZI_alpha1.5.cfg  -c "program build/STM32H743ZI_alpha1.5_makefile.elf verify reset exit"

