sudo uhubctl -a 0 -p 3 -l 1-1.1
sudo uhubctl -a 1 -p 3 -l 1-1.1
