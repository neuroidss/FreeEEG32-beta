#ln -s ./docker-compose-openvibe-server-freeeeg32.service /etc/systemd/system
systemctl disable docker-compose-openvibe-freeeeg32
